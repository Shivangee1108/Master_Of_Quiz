import { create } from 'zustand';
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { useAuthStore } from './useAuthStore';

export type Difficulty = 'Easy' | 'Medium' | 'Hard';
export type QuestionType = 'Multiple Choice' | 'True/False' | 'Mixed';

export interface Question {
  id: string;
  text: string;
  options: string[];
  correctAnswer: string;
  explanation: string;
  type: 'Multiple Choice' | 'True/False';
}

export interface QuizResult {
  id: string;
  topic: string;
  difficulty: Difficulty;
  score: number;
  totalQuestions: number;
  correctAnswers: number;
  wrongAnswers: number;
  skipped: number;
  timeTaken: number; // in seconds
  date: string;
  questions: Question[];
  userAnswers: Record<string, string>;
}

interface QuizState {
  history: QuizResult[];
  status: 'idle' | 'setup' | 'generating' | 'active' | 'finished';
  currentQuiz: {
    id: string;
    topic: string;
    difficulty: Difficulty;
    type: QuestionType;
    questions: Question[];
    userAnswers: Record<string, string>;
    startTime: number;
    timeRemaining: number;
    currentIndex: number;
  } | null;
  
  setStatus: (status: QuizState['status']) => void;
  startQuiz: (topic: string, difficulty: Difficulty, type: QuestionType, questions: Question[], timeLimit: number) => void;
  answerQuestion: (questionId: string, answer: string) => void;
  skipQuestion: (questionId: string) => void;
  setCurrentIndex: (index: number) => void;
  submitQuiz: () => void;
  resetCurrentQuiz: () => void;
  updateTimeRemaining: (time: number) => void;
  clearHistory: () => void;
  deleteHistoryItem: (id: string) => void;
  loadHistory: (history: QuizResult[]) => void;
}

export const useQuizStore = create<QuizState>()((set, get) => ({
  history: [],
  status: 'idle',
  currentQuiz: null,
  
  setStatus: (status) => set({ status }),
  
  startQuiz: (topic, difficulty, type, questions, timeLimit) => set({
    status: 'active',
    currentQuiz: {
      id: crypto.randomUUID(),
      topic,
      difficulty,
      type,
      questions,
      userAnswers: {},
      startTime: Date.now(),
      timeRemaining: timeLimit,
      currentIndex: 0,
    }
  }),
  
  answerQuestion: (questionId, answer) => set((state) => {
    if (!state.currentQuiz) return state;
    return {
      currentQuiz: {
        ...state.currentQuiz,
        userAnswers: {
          ...state.currentQuiz.userAnswers,
          [questionId]: answer
        }
      }
    };
  }),
  
  skipQuestion: (questionId) => set((state) => {
    if (!state.currentQuiz) return state;
    const newAnswers = { ...state.currentQuiz.userAnswers };
    delete newAnswers[questionId];
    return {
      currentQuiz: {
        ...state.currentQuiz,
        userAnswers: newAnswers
      }
    };
  }),
  
  setCurrentIndex: (index) => set((state) => {
    if (!state.currentQuiz) return state;
    return {
      currentQuiz: {
        ...state.currentQuiz,
        currentIndex: index
      }
    };
  }),
  
  submitQuiz: async () => {
    const { currentQuiz, history } = get();
    if (!currentQuiz) return;
    
    let correct = 0;
    let wrong = 0;
    let skipped = 0;
    
    currentQuiz.questions.forEach(q => {
      const ans = currentQuiz.userAnswers[q.id];
      if (!ans) {
        skipped++;
      } else if (ans === q.correctAnswer) {
        correct++;
      } else {
        wrong++;
      }
    });
    
    const timeTaken = Math.floor((Date.now() - currentQuiz.startTime) / 1000);
    
    const result: QuizResult = {
      id: currentQuiz.id,
      topic: currentQuiz.topic,
      difficulty: currentQuiz.difficulty,
      score: Math.round((correct / currentQuiz.questions.length) * 100),
      totalQuestions: currentQuiz.questions.length,
      correctAnswers: correct,
      wrongAnswers: wrong,
      skipped,
      timeTaken,
      date: new Date().toISOString(),
      questions: currentQuiz.questions,
      userAnswers: currentQuiz.userAnswers
    };
    
    const newHistory = [result, ...history];
    set({ status: 'finished', history: newHistory });

    // Save to Supabase if logged in
    const { user, isGuest } = useAuthStore.getState();
    if (user && !isGuest && isSupabaseConfigured && supabase) {
      try {
        await supabase.from('quiz_history').insert({
          id: result.id,
          user_id: user.id,
          topic: result.topic,
          difficulty: result.difficulty,
          score: result.score,
          total_questions: result.totalQuestions,
          correct_answers: result.correctAnswers,
          wrong_answers: result.wrongAnswers,
          skipped: result.skipped,
          time_taken: result.timeTaken,
          date: result.date,
          questions: result.questions,
          user_answers: result.userAnswers
        });
      } catch (err) {
        console.error('Failed to save to Supabase', err);
      }
    }
  },
  
  resetCurrentQuiz: () => set({ status: 'idle', currentQuiz: null }),
  
  updateTimeRemaining: (time) => set((state) => {
    if (!state.currentQuiz) return state;
    return {
      currentQuiz: {
        ...state.currentQuiz,
        timeRemaining: time
      }
    };
  }),
  
  clearHistory: async () => {
    set({ history: [] });
    const { user, isGuest } = useAuthStore.getState();
    if (user && !isGuest && isSupabaseConfigured && supabase) {
      try {
        await supabase.from('quiz_history').delete().eq('user_id', user.id);
      } catch (err) {
        console.error('Failed to clear Supabase history', err);
      }
    }
  },
  
  deleteHistoryItem: async (id) => {
    set((state) => ({ history: state.history.filter((item) => item.id !== id) }));
    const { user, isGuest } = useAuthStore.getState();
    if (user && !isGuest && isSupabaseConfigured && supabase) {
      try {
        await supabase.from('quiz_history').delete().eq('id', id);
      } catch (err) {
        console.error('Failed to delete from Supabase', err);
      }
    }
  },

  loadHistory: (history) => set({ history })
}));
