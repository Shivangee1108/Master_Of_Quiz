import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { supabase, isSupabaseConfigured } from '../lib/supabase';

export interface User {
  id: string;
  name: string;
  emailOrMobile: string;
  profilePicture?: string;
  role?: 'user' | 'admin';
  createdAt?: string;
}

interface AuthState {
  user: User | null;
  isGuest: boolean;
  login: (user: User) => void;
  updateUser: (updates: Partial<User>) => void;
  loginAsGuest: () => void;
  logout: () => void;
  syncSession: () => Promise<void>;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      isGuest: false,
      login: (user) => set({ user, isGuest: false }),
      updateUser: (updates) => set((state) => ({
        user: state.user ? { ...state.user, ...updates } : null
      })),
      loginAsGuest: () => set({ user: null, isGuest: true }),
      logout: async () => {
        if (isSupabaseConfigured && supabase) {
          await supabase.auth.signOut();
        }
        set({ user: null, isGuest: false });
      },
      syncSession: async () => {
        if (!isSupabaseConfigured || !supabase) return;
        
        const { data: { session } } = await supabase.auth.getSession();
        if (session) {
          const { data: profile } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', session.user.id)
            .single();
            
          if (profile) {
            set({ 
              user: {
                id: profile.id,
                name: profile.name,
                emailOrMobile: profile.email,
                role: profile.role,
                profilePicture: profile.profile_picture,
                createdAt: profile.created_at
              },
              isGuest: false 
            });
          }
        } else {
          const state = get();
          if (!state.isGuest) {
            set({ user: null });
          }
        }
      }
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({ user: state.user, isGuest: state.isGuest }),
    }
  )
);
