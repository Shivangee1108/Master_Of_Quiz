import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { BrainCircuit, Github, LogOut, User, Shield } from 'lucide-react';
import ThemeToggle from './ThemeToggle';
import { useAuthStore } from '../store/useAuthStore';

export default function Layout({ children }: { children: React.ReactNode }) {
  const { user, isGuest, logout } = useAuthStore();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-50 font-sans transition-colors duration-300">
      <header className="sticky top-0 z-50 w-full border-b border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-950/80 backdrop-blur">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400 hover:opacity-80 transition-opacity">
            <BrainCircuit className="w-8 h-8" />
            <span className="font-bold text-xl tracking-tight text-slate-900 dark:text-white">Master of Quiz</span>
          </Link>
          
          <nav className="flex items-center gap-2 md:gap-4">
            <ThemeToggle />
            
            {user ? (
              <div className="flex items-center gap-3 border-l border-slate-200 dark:border-slate-700 pl-2 md:pl-4">
                {user.role === 'admin' && (
                  <button 
                    onClick={() => navigate('/admin')}
                    className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 font-medium hover:bg-rose-100 dark:hover:bg-rose-500/20 transition-colors"
                  >
                    <Shield className="w-4 h-4" />
                    <span className="hidden md:block">Admin</span>
                  </button>
                )}
                <button 
                  onClick={() => navigate('/profile')}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors group"
                  title="View Profile"
                >
                  {user.profilePicture ? (
                    <img 
                      src={user.profilePicture} 
                      alt={user.name} 
                      className="w-7 h-7 rounded-full object-cover shrink-0 border border-slate-200 dark:border-slate-700"
                    />
                  ) : (
                    <div className="w-7 h-7 rounded-full bg-indigo-100 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 flex items-center justify-center text-xs font-bold shrink-0">
                      {user.name.charAt(0).toUpperCase()}
                    </div>
                  )}
                  <span className="text-sm font-medium hidden md:block text-slate-600 dark:text-slate-300 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                    {user.name}
                  </span>
                </button>
              </div>
            ) : isGuest ? (
              <div className="border-l border-slate-200 dark:border-slate-700 pl-2 md:pl-4">
                <button onClick={logout} className="px-3 py-1.5 rounded-lg text-sm font-medium text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-500/10 transition-colors">
                  Sign In
                </button>
              </div>
            ) : null}
          </nav>
        </div>
      </header>
      
      <main className="container mx-auto px-4 py-8 max-w-5xl">
        {children}
      </main>
      
      <footer className="border-t border-slate-200 dark:border-slate-800 py-8 mt-12 text-center text-slate-500 dark:text-slate-400">
        <p>© {new Date().getFullYear()} Master of Quiz. Built with React & Tailwind.</p>
      </footer>
    </div>
  );
}
