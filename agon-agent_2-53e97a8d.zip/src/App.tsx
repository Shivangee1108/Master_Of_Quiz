import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import QuizActive from './pages/QuizActive';
import QuizResults from './pages/QuizResults';
import QuizReview from './pages/QuizReview';
import AuthPage from './pages/AuthPage';
import Profile from './pages/Profile';
import AdminDashboard from './pages/AdminDashboard';
import { useQuizStore } from './store/useQuizStore';
import { useAuthStore } from './store/useAuthStore';
import { supabase, isSupabaseConfigured } from './lib/supabase';

function App() {
  const status = useQuizStore((state) => state.status);
  const { user, isGuest, syncSession } = useAuthStore();

  // Sync Supabase session on mount
  useEffect(() => {
    syncSession();
  }, [syncSession]);

  // Load history when auth state changes
  useEffect(() => {
    async function loadData() {
      if (user && isSupabaseConfigured && supabase) {
        try {
          const { data, error } = await supabase
            .from('quiz_history')
            .select('*')
            .eq('user_id', user.id)
            .order('date', { ascending: false });
            
          if (!error && data) {
            // Map snake_case to camelCase
            const mappedHistory = data.map(item => ({
              id: item.id,
              topic: item.topic,
              difficulty: item.difficulty,
              score: item.score,
              totalQuestions: item.total_questions,
              correctAnswers: item.correct_answers,
              wrongAnswers: item.wrong_answers,
              skipped: item.skipped,
              timeTaken: item.time_taken,
              date: item.date,
              questions: item.questions,
              userAnswers: item.user_answers
            }));
            useQuizStore.getState().loadHistory(mappedHistory);
          }
        } catch (err) {
          console.error("Failed to load history", err);
        }
      } else if (user) {
        // Fallback to local storage if Supabase not configured
        const data = localStorage.getItem(`quiz_data_${user.id}`);
        useQuizStore.getState().loadHistory(data ? JSON.parse(data) : []);
      } else if (isGuest) {
        const data = sessionStorage.getItem(`quiz_data_guest`);
        useQuizStore.getState().loadHistory(data ? JSON.parse(data) : []);
      } else {
        useQuizStore.getState().loadHistory([]);
      }
    }
    
    loadData();
  }, [user, isGuest]);

  // Save history on changes (only for local fallback and guest)
  useEffect(() => {
    const unsub = useQuizStore.subscribe((state, prevState) => {
      if (state.history !== prevState.history) {
        const { user, isGuest } = useAuthStore.getState();
        if (user && !isSupabaseConfigured) {
          localStorage.setItem(`quiz_data_${user.id}`, JSON.stringify(state.history));
        } else if (isGuest) {
          sessionStorage.setItem(`quiz_data_guest`, JSON.stringify(state.history));
        }
      }
    });
    return unsub;
  }, []);

  if (!user && !isGuest) {
    return <AuthPage />;
  }

  return (
    <BrowserRouter>
      <Layout>
        {isGuest && (
          <div className="mb-6 bg-amber-100 dark:bg-amber-900/30 text-amber-800 dark:text-amber-400 p-3 rounded-xl text-sm font-medium flex flex-col md:flex-row items-center justify-between gap-2 border border-amber-200 dark:border-amber-800">
            <span>Guest data is temporary and will not be saved after closing the website.</span>
            <button onClick={() => useAuthStore.getState().logout()} className="underline hover:text-amber-900 dark:hover:text-amber-300 whitespace-nowrap">
              Sign up to save
            </button>
          </div>
        )}
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/quiz" element={
            status === 'active' ? <QuizActive /> : <Navigate to="/" replace />
          } />
          <Route path="/results" element={
            status === 'finished' ? <QuizResults /> : <Navigate to="/" replace />
          } />
          <Route path="/review/:id" element={<QuizReview />} />
          <Route path="/profile" element={
            user ? <Profile /> : <Navigate to="/" replace />
          } />
          <Route path="/admin" element={
            user?.role === 'admin' ? <AdminDashboard /> : <Navigate to="/" replace />
          } />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  );
}

export default App;
