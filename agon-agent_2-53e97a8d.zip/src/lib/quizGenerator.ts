import { Question, Difficulty, QuestionType } from '../store/useQuizStore';

const topicsDB: Record<string, any[]> = {
  python: [
    {
      text: "Which of the following is used to define a function in Python?",
      options: ["def", "function", "fun", "define"],
      correctAnswer: "def",
      explanation: "In Python, the 'def' keyword is used to start the definition of a function."
    },
    {
      text: "What is the output of print(2 ** 3)?",
      options: ["6", "8", "9", "12"],
      correctAnswer: "8",
      explanation: "The '**' operator is used for exponentiation in Python, so 2 ** 3 means 2 to the power of 3, which is 8."
    },
    {
      text: "Python is a compiled language.",
      options: ["True", "False"],
      correctAnswer: "False",
      explanation: "Python is an interpreted language, not a compiled language. The source code is executed line by line by the Python interpreter."
    }
  ],
  react: [
    {
      text: "Which hook is used to manage state in a functional component?",
      options: ["useEffect", "useState", "useContext", "useReducer"],
      correctAnswer: "useState",
      explanation: "The useState hook allows you to add state to functional components in React."
    },
    {
      text: "React primarily uses which of the following to update the UI?",
      options: ["Real DOM", "Shadow DOM", "Virtual DOM", "Document Object Model"],
      correctAnswer: "Virtual DOM",
      explanation: "React uses a Virtual DOM to improve performance by calculating the minimal number of DOM operations required to update the UI."
    }
  ],
  history: [
    {
      text: "In which year did World War II end?",
      options: ["1943", "1945", "1947", "1950"],
      correctAnswer: "1945",
      explanation: "World War II ended in 1945 with the surrender of Germany in May and Japan in September."
    },
    {
      text: "Who was the first President of the United States?",
      options: ["Thomas Jefferson", "John Adams", "George Washington", "Abraham Lincoln"],
      correctAnswer: "George Washington",
      explanation: "George Washington served as the first President of the United States from 1789 to 1797."
    }
  ]
};

const genericTemplates = [
  {
    q: "Which of the following is a primary characteristic of {topic}?",
    opts: ["It relies on fundamental principles", "It is completely random", "It has no practical application", "It was invented recently"],
    ans: "It relies on fundamental principles",
    exp: "Like most established fields, {topic} is built upon fundamental principles that guide its application."
  },
  {
    q: "In the context of {topic}, what is generally considered the most important factor?",
    opts: ["Consistency and accuracy", "Speed over quality", "Ignoring past data", "Aesthetic appeal"],
    ans: "Consistency and accuracy",
    exp: "In {topic}, maintaining consistency and accuracy is crucial for reliable outcomes."
  },
  {
    q: "The study or application of {topic} has significantly evolved over the last decade.",
    opts: ["True", "False"],
    ans: "True",
    exp: "Almost all fields, including {topic}, have seen rapid evolution due to technological advancements in recent years."
  },
  {
    q: "Who or what typically benefits the most from advancements in {topic}?",
    opts: ["Professionals and enthusiasts in the field", "Only academics", "No one", "Only beginners"],
    ans: "Professionals and enthusiasts in the field",
    exp: "Advancements in {topic} provide new tools and methodologies that benefit those actively engaged in the field."
  },
  {
    q: "Which concept is NOT typically associated with {topic}?",
    opts: ["Irrelevant metaphysical phenomena", "Core foundational theories", "Practical implementation", "Continuous improvement"],
    ans: "Irrelevant metaphysical phenomena",
    exp: "Unless {topic} is specifically about metaphysics, it generally focuses on its own core theories and practical implementations."
  }
];

export async function generateQuizQuestions(
  topic: string,
  count: number,
  difficulty: Difficulty,
  type: QuestionType
): Promise<Question[]> {
  // Simulate network delay for AI generation
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  const normalizedTopic = topic.toLowerCase().trim();
  let sourceQuestions = topicsDB[normalizedTopic] || [];
  
  let questions: Question[] = [];
  
  // If we have specific questions for this topic in our DB
  if (sourceQuestions.length > 0) {
    // Shuffle and pick
    const shuffled = [...sourceQuestions].sort(() => 0.5 - Math.random());
    questions = shuffled.slice(0, count).map((q, i) => ({
      id: `q_${i}_${Date.now()}`,
      text: q.text,
      options: q.options,
      correctAnswer: q.correctAnswer,
      explanation: q.explanation,
      type: q.options.length === 2 ? 'True/False' : 'Multiple Choice'
    }));
  }
  
  // Fill remaining with generic generated questions
  let templateIndex = 0;
  while (questions.length < count) {
    const template = genericTemplates[templateIndex % genericTemplates.length];
    const isTrueFalse = template.opts.length === 2;
    
    // Filter by type if needed
    if (type === 'Multiple Choice' && isTrueFalse) {
      templateIndex++;
      continue;
    }
    if (type === 'True/False' && !isTrueFalse) {
      templateIndex++;
      continue;
    }
    
    const formattedTopic = topic.charAt(0).toUpperCase() + topic.slice(1);
    
    questions.push({
      id: `q_gen_${questions.length}_${Date.now()}`,
      text: template.q.replace(/{topic}/g, formattedTopic),
      options: [...template.opts].sort(() => 0.5 - Math.random()), // Shuffle options
      correctAnswer: template.ans,
      explanation: template.exp.replace(/{topic}/g, formattedTopic),
      type: isTrueFalse ? 'True/False' : 'Multiple Choice'
    });
    
    templateIndex++;
  }
  
  // Shuffle final questions
  return questions.sort(() => 0.5 - Math.random());
}
