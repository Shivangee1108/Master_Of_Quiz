import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Users, Mail, Calendar, BarChart2, CheckCircle2, XCircle, ShieldAlert } from 'lucide-react';
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { formatTime } from '../lib/utils';

interface AdminStats {
  totalUsers: number;
  totalQuizzes: number;
  averageScore: number;
}

interface UserData {
  id: string;
  name: string;
  email: string;
  created_at: string;
}

export default function AdminDashboard() {
  const [stats, setStats] = useState<AdminStats>({ totalUsers: 0, totalQuizzes: 0, averageScore: 0 });
  const [users, setUsers] = useState<UserData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchAdminData() {
      if (!isSupabaseConfigured || !supabase) {
        setLoading(false);
        return;
      }

      try {
        // Fetch profiles
        const { data: profilesData, error: profilesError } = await supabase
          .from('profiles')
          .select('id, name, email, created_at')
          .order('created_at', { ascending: false });

        if (profilesData) {
          setUsers(profilesData);
          setStats(s => ({ ...s, totalUsers: profilesData.length }));
        }

        // Fetch quiz history stats
        const { data: quizData, error: quizError } = await supabase
          .from('quiz_history')
          .select('score');

        if (quizData) {
          const totalQuizzes = quizData.length;
          const avgScore = totalQuizzes > 0 
            ? Math.round(quizData.reduce((acc, curr) => acc + curr.score, 0) / totalQuizzes) 
            : 0;
            
          setStats(s => ({ ...s, totalQuizzes, averageScore: avgScore }));
        }
      } catch (err) {
        console.error("Failed to fetch admin data", err);
      } finally {
        setLoading(false);
      }
    }

    fetchAdminData();
  }, []);

  if (!isSupabaseConfigured) {
    return (
      <div className="text-center py-20 space-y-4">
        <ShieldAlert className="w-16 h-16 text-rose-500 mx-auto" />
        <h2 className="text-2xl font-bold">Admin Dashboard Unavailable</h2>
        <p className="text-slate-500">Supabase is not configured. Admin dashboard requires a real database.</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="w-8 h-8 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-6xl mx-auto space-y-8"
    >
      <div className="flex items-center gap-3 mb-8">
        <div className="p-3 bg-rose-100 dark:bg-rose-500/20 text-rose-600 dark:text-rose-400 rounded-2xl">
          <ShieldAlert className="w-8 h-8" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Admin Dashboard</h1>
          <p className="text-slate-500 dark:text-slate-400">Platform overview and user management</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid md:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-200 dark:border-slate-800 flex items-center gap-4">
          <div className="p-4 bg-indigo-100 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 rounded-2xl">
            <Users className="w-8 h-8" />
          </div>
          <div>
            <p className="text-sm font-bold text-slate-500 uppercase tracking-wider">Total Users</p>
            <p className="text-3xl font-extrabold text-slate-900 dark:text-white">{stats.totalUsers}</p>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-200 dark:border-slate-800 flex items-center gap-4">
          <div className="p-4 bg-emerald-100 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-2xl">
            <BarChart2 className="w-8 h-8" />
          </div>
          <div>
            <p className="text-sm font-bold text-slate-500 uppercase tracking-wider">Total Quizzes</p>
            <p className="text-3xl font-extrabold text-slate-900 dark:text-white">{stats.totalQuizzes}</p>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-200 dark:border-slate-800 flex items-center gap-4">
          <div className="p-4 bg-amber-100 dark:bg-amber-500/20 text-amber-600 dark:text-amber-400 rounded-2xl">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <div>
            <p className="text-sm font-bold text-slate-500 uppercase tracking-wider">Avg Platform Score</p>
            <p className="text-3xl font-extrabold text-slate-900 dark:text-white">{stats.averageScore}%</p>
          </div>
        </div>
      </div>

      {/* Users Table */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden">
        <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
          <Users className="w-5 h-5 text-indigo-500" /> Registered Users
        </h3>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800">
                <th className="py-4 px-4 text-sm font-bold text-slate-500 uppercase tracking-wider">Name</th>
                <th className="py-4 px-4 text-sm font-bold text-slate-500 uppercase tracking-wider">Email</th>
                <th className="py-4 px-4 text-sm font-bold text-slate-500 uppercase tracking-wider">Registration Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/50">
              {users.map((u) => (
                <tr key={u.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                  <td className="py-4 px-4 font-medium text-slate-900 dark:text-white capitalize">{u.name}</td>
                  <td className="py-4 px-4 text-slate-600 dark:text-slate-400 flex items-center gap-2">
                    <Mail className="w-4 h-4 text-slate-400" /> {u.email}
                  </td>
                  <td className="py-4 px-4 text-slate-600 dark:text-slate-400 flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-slate-400" /> 
                    {new Date(u.created_at).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })}
                  </td>
                </tr>
              ))}
              {users.length === 0 && (
                <tr>
                  <td colSpan={3} className="py-8 text-center text-slate-500">No users found.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </motion.div>
  );
}
