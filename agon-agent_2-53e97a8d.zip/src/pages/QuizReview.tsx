import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Clock, CheckCircle2, XCircle, RotateCcw, Home, AlertCircle, Calendar } from 'lucide-react';
import { useQuizStore, Difficulty, QuestionType } from '../store/useQuizStore';
import { cn, formatTime } from '../lib/utils';
import { generateQuizQuestions } from '../lib/quizGenerator';

export default function QuizReview() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { history, startQuiz, setStatus } = useQuizStore();
  
  const result = history.find(h => h.id === id);

  if (!result) {
    return (
      <div className="text-center py-20 space-y-4">
        <h2 className="text-2xl font-bold">Quiz attempt not found</h2>
        <button onClick={() => navigate('/')} className="text-indigo-500 hover:underline">
          Go back to dashboard
        </button>
      </div>
    );
  }

  const handleRetry = async () => {
    // Generate new questions for the same topic
    setStatus('generating');
    navigate('/'); // temporary navigate to home to show generating state, or we can just handle it here
    
    try {
      // Assuming a default of Mixed if we don't have the original type explicitly stored (we added it, but old data might not have it)
      const type: QuestionType = 'Mixed'; 
      const questions = await generateQuizQuestions(result.topic, result.totalQuestions, result.difficulty, type);
      const timeLimit = result.totalQuestions * 30;
      startQuiz(result.topic, result.difficulty, type, questions, timeLimit);
      navigate('/quiz');
    } catch (error) {
      console.error(error);
      setStatus('idle');
      navigate('/');
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-emerald-500';
    if (score >= 50) return 'text-amber-500';
    return 'text-rose-500';
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-4xl mx-auto py-8 space-y-8"
    >
      {/* Header & Summary */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 shadow-sm border border-slate-200 dark:border-slate-800 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500"></div>
        
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-8">
          <div>
            <h2 className="text-3xl font-bold capitalize mb-2">{result.topic} Quiz Review</h2>
            <div className="flex flex-wrap items-center gap-4 text-sm text-slate-500 dark:text-slate-400">
              <span className="flex items-center gap-1"><Calendar className="w-4 h-4" /> {new Date(result.date).toLocaleDateString()} at {new Date(result.date).toLocaleTimeString()}</span>
              <span>•</span>
              <span className="px-2 py-1 rounded-md bg-slate-100 dark:bg-slate-800 font-medium">{result.difficulty}</span>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <button 
              onClick={() => navigate('/')}
              className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
              title="Back to Dashboard"
            >
              <Home className="w-5 h-5" />
            </button>
            <button 
              onClick={handleRetry}
              className="px-6 py-2 rounded-xl font-bold flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white shadow-lg shadow-indigo-600/30 transition-all"
            >
              <RotateCcw className="w-4 h-4" />
              Retry Quiz
            </button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 text-center">
            <p className="text-sm text-slate-500 mb-1">Score</p>
            <p className={cn("text-2xl font-bold", getScoreColor(result.score))}>{result.score}%</p>
          </div>
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 text-center">
            <p className="text-sm text-slate-500 mb-1">Questions</p>
            <p className="text-2xl font-bold">{result.totalQuestions}</p>
          </div>
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 text-center">
            <p className="text-sm text-slate-500 mb-1">Correct</p>
            <p className="text-2xl font-bold text-emerald-500">{result.correctAnswers}</p>
          </div>
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 text-center">
            <p className="text-sm text-slate-500 mb-1">Wrong</p>
            <p className="text-2xl font-bold text-rose-500">{result.wrongAnswers + result.skipped}</p>
          </div>
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 text-center col-span-2 md:col-span-1">
            <p className="text-sm text-slate-500 mb-1">Time Taken</p>
            <p className="text-2xl font-bold">{formatTime(result.timeTaken)}</p>
          </div>
        </div>
      </div>

      {/* Detailed Review */}
      <div>
        <h3 className="text-2xl font-bold mb-6 flex items-center gap-2">
          <AlertCircle className="w-6 h-6 text-indigo-500" />
          Question Breakdown
        </h3>
        
        <div className="space-y-6">
          {result.questions.map((q, idx) => {
            const userAnswer = result.userAnswers[q.id];
            const isCorrect = userAnswer === q.correctAnswer;
            const isSkipped = !userAnswer;

            return (
              <div key={q.id} className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-200 dark:border-slate-800">
                <div className="flex items-start gap-4 mb-4">
                  <div className={cn(
                    "flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm text-white mt-1",
                    isCorrect ? "bg-emerald-500" : isSkipped ? "bg-slate-400" : "bg-rose-500"
                  )}>
                    {idx + 1}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between gap-4">
                      <h4 className="text-lg font-medium text-slate-900 dark:text-white leading-relaxed">{q.text}</h4>
                      {!isSkipped && (
                        <div className={cn(
                          "px-3 py-1 rounded-full text-xs font-bold whitespace-nowrap",
                          isCorrect ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-400" : "bg-rose-100 text-rose-700 dark:bg-rose-500/20 dark:text-rose-400"
                        )}>
                          {isCorrect ? 'Correct ✅' : 'Wrong ❌'}
                        </div>
                      )}
                      {isSkipped && (
                        <div className="px-3 py-1 rounded-full text-xs font-bold whitespace-nowrap bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-400">
                          Skipped
                        </div>
                      )}
                    </div>

                    <div className="mt-6 space-y-3">
                      {q.options.map((opt, oIdx) => {
                        const isSelected = userAnswer === opt;
                        const isActualCorrect = q.correctAnswer === opt;
                        
                        let optClass = "border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 opacity-70";
                        if (isActualCorrect) {
                          optClass = "border-emerald-500 bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 shadow-sm";
                        } else if (isSelected && !isActualCorrect) {
                          optClass = "border-rose-500 bg-rose-50 dark:bg-rose-500/10 text-rose-700 dark:text-rose-300 shadow-sm";
                        }

                        return (
                          <div key={oIdx} className={cn("p-4 rounded-xl border-2 flex items-center justify-between transition-all", optClass)}>
                            <span className="font-medium">{opt}</span>
                            {isActualCorrect && <CheckCircle2 className="w-5 h-5 text-emerald-500" />}
                            {isSelected && !isActualCorrect && <XCircle className="w-5 h-5 text-rose-500" />}
                          </div>
                        );
                      })}
                    </div>
                    
                    <div className="mt-6 p-5 rounded-xl bg-indigo-50 dark:bg-indigo-500/10 border border-indigo-100 dark:border-indigo-500/20">
                      <p className="text-indigo-900 dark:text-indigo-200 leading-relaxed">
                        <strong className="font-bold flex items-center gap-2 mb-2 text-indigo-700 dark:text-indigo-400">
                          <AlertCircle className="w-4 h-4" /> Explanation
                        </strong>
                        {q.explanation}
                      </p>
                      {!isCorrect && !isSkipped && (
                        <p className="mt-3 text-sm text-rose-600 dark:text-rose-400 font-medium">
                          You selected "{userAnswer}", which is incorrect.
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </motion.div>
  );
}
