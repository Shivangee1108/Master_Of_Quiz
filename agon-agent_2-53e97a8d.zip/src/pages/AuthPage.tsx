import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { BrainCircuit, UserPlus, LogIn, User, ArrowLeft, AlertCircle, CheckCircle2 } from 'lucide-react';
import { useAuthStore } from '../store/useAuthStore';
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { cn } from '../lib/utils';
import ThemeToggle from '../components/ThemeToggle';

type AuthView = 'landing' | 'signin' | 'signup' | 'forgot';

export default function AuthPage() {
  const [view, setView] = useState<AuthView>('landing');
  const { login, loginAsGuest } = useAuthStore();
  
  // Form states
  const [name, setName] = useState('');
  const [emailOrMobile, setEmailOrMobile] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('deleted') === 'true') {
      setSuccessMessage('Your account and all associated data have been deleted successfully.');
      window.history.replaceState({}, document.title, '/');
      setTimeout(() => setSuccessMessage(''), 5000);
    }
  }, []);

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!name || !emailOrMobile || !password || !confirmPassword) {
      setError('All fields are required.');
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }

    if (!isSupabaseConfigured || !supabase) {
      setError('System Error: Database connection is missing. Please contact the administrator.');
      return;
    }

    setIsLoading(true);

    try {
        const { data: authData, error: authError } = await supabase.auth.signUp({
          email: emailOrMobile,
          password: password,
          options: {
            data: {
              name: name
            }
          }
        });

        if (authError) throw authError;

        if (authData.user) {
          if (!authData.session) {
            setSuccessMessage('Please check your email to verify your account.');
            setView('signin');
          } else {
            login({
              id: authData.user.id,
              name: name,
              emailOrMobile: emailOrMobile,
              role: 'user',
              createdAt: new Date().toISOString()
            });
          }
        }
    } catch (err: any) {
      setError(err.message || 'Failed to sign up.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!isSupabaseConfigured || !supabase) {
      setError('System Error: Database connection is missing. Please contact the administrator.');
      return;
    }

    setIsLoading(true);

    try {
      // Supabase Auth
      const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
        email: emailOrMobile,
        password: password,
      });

      if (authError) throw authError;

      if (authData.user) {
        // Fetch profile
        const { data: profile } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', authData.user.id)
          .single();

        if (profile) {
          login({
            id: profile.id,
            name: profile.name,
            emailOrMobile: profile.email,
            role: profile.role,
            profilePicture: profile.profile_picture,
            createdAt: profile.created_at
          });
        }
      }
    } catch (err: any) {
      setError(err.message || 'Invalid credentials or failed to sign in.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgot = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    // Mock forgot password
    alert('A password reset link has been sent to ' + emailOrMobile);
    setView('signin');
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col transition-colors duration-300">
      <div className="p-4 flex justify-end">
        <ThemeToggle />
      </div>
      
      <div className="flex-1 flex flex-col items-center justify-center p-4 relative">
        <AnimatePresence>
          {successMessage && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="absolute top-4 left-1/2 -translate-x-1/2 w-[90%] max-w-md bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 p-4 rounded-2xl border border-emerald-200 dark:border-emerald-900/50 flex items-start gap-3 shadow-lg"
            >
              <CheckCircle2 className="w-5 h-5 shrink-0 mt-0.5" />
              <p className="text-sm font-medium">{successMessage}</p>
            </motion.div>
          )}
        </AnimatePresence>

        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-3 mb-8"
        >
          <div className="p-3 bg-indigo-600 rounded-2xl shadow-lg shadow-indigo-600/30">
            <BrainCircuit className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl font-extrabold tracking-tight text-slate-900 dark:text-white">Master of Quiz</h1>
        </motion.div>

        <AnimatePresence mode="wait">
          {view === 'landing' && (
            <motion.div
              key="landing"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-md space-y-4"
            >
              <button
                onClick={() => setView('signup')}
                className="w-full p-4 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-lg flex items-center justify-center gap-3 transition-all shadow-lg shadow-indigo-600/30 group"
              >
                <UserPlus className="w-6 h-6 group-hover:scale-110 transition-transform" />
                Create Account
              </button>
              
              <button
                onClick={() => setView('signin')}
                className="w-full p-4 rounded-2xl bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-800 hover:border-indigo-500 dark:hover:border-indigo-500 text-slate-900 dark:text-white font-bold text-lg flex items-center justify-center gap-3 transition-all group"
              >
                <LogIn className="w-6 h-6 group-hover:scale-110 transition-transform" />
                Sign In
              </button>
              
              <button
                onClick={loginAsGuest}
                className="w-full p-4 rounded-2xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-lg flex items-center justify-center gap-3 transition-all group mt-8"
              >
                <User className="w-6 h-6 group-hover:scale-110 transition-transform" />
                Continue as Guest
              </button>
              
              <p className="text-center text-sm text-slate-500 dark:text-slate-400 mt-4 px-6">
                Guest progress is temporary and will be lost after closing the website.
              </p>
            </motion.div>
          )}

          {view === 'signup' && (
            <motion.div
              key="signup"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="w-full max-w-md bg-white dark:bg-slate-900 p-8 rounded-3xl shadow-xl border border-slate-200 dark:border-slate-800"
            >
              <button onClick={() => setView('landing')} className="mb-6 flex items-center gap-2 text-sm font-medium text-slate-500 hover:text-slate-900 dark:hover:text-white transition-colors">
                <ArrowLeft className="w-4 h-4" /> Back
              </button>
              
              <h2 className="text-2xl font-bold mb-6 text-slate-900 dark:text-white">Create an Account</h2>
              
              {error && <div className="mb-4 p-3 rounded-lg bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 text-sm font-medium flex items-center gap-2"><AlertCircle className="w-4 h-4" /> {error}</div>}
              
              <form onSubmit={handleSignUp} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1.5 text-slate-700 dark:text-slate-300">Name</label>
                  <input type="text" value={name} onChange={e => setName(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white" placeholder="John Doe" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5 text-slate-700 dark:text-slate-300">Email or Mobile Number</label>
                  <input type="text" value={emailOrMobile} onChange={e => setEmailOrMobile(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white" placeholder="john@example.com" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5 text-slate-700 dark:text-slate-300">Password</label>
                  <input type="password" value={password} onChange={e => setPassword(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white" placeholder="••••••••" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5 text-slate-700 dark:text-slate-300">Confirm Password</label>
                  <input type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white" placeholder="••••••••" />
                </div>
                <button type="submit" disabled={isLoading} className="w-full py-3.5 mt-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-lg transition-all shadow-lg shadow-indigo-600/30 disabled:opacity-70 flex items-center justify-center">
                  {isLoading ? <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : 'Sign Up'}
                </button>
              </form>
              
              <p className="text-center mt-6 text-sm text-slate-500 dark:text-slate-400">
                Already have an account? <button onClick={() => setView('signin')} className="text-indigo-600 dark:text-indigo-400 font-bold hover:underline">Sign In</button>
              </p>
            </motion.div>
          )}

          {view === 'signin' && (
            <motion.div
              key="signin"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="w-full max-w-md bg-white dark:bg-slate-900 p-8 rounded-3xl shadow-xl border border-slate-200 dark:border-slate-800"
            >
              <button onClick={() => setView('landing')} className="mb-6 flex items-center gap-2 text-sm font-medium text-slate-500 hover:text-slate-900 dark:hover:text-white transition-colors">
                <ArrowLeft className="w-4 h-4" /> Back
              </button>
              
              <h2 className="text-2xl font-bold mb-6 text-slate-900 dark:text-white">Welcome Back</h2>
              
              {error && <div className="mb-4 p-3 rounded-lg bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 text-sm font-medium flex items-center gap-2"><AlertCircle className="w-4 h-4" /> {error}</div>}
              
              <form onSubmit={handleSignIn} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1.5 text-slate-700 dark:text-slate-300">Email or Mobile Number</label>
                  <input type="text" value={emailOrMobile} onChange={e => setEmailOrMobile(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white" placeholder="john@example.com" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5 text-slate-700 dark:text-slate-300">Password</label>
                  <input type="password" value={password} onChange={e => setPassword(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white" placeholder="••••••••" />
                </div>
                
                <div className="flex items-center justify-between mt-2">
                  <label className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400 cursor-pointer">
                    <input type="checkbox" className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 w-4 h-4" defaultChecked />
                    Remember Me
                  </label>
                  <button type="button" onClick={() => setView('forgot')} className="text-sm font-medium text-indigo-600 dark:text-indigo-400 hover:underline">
                    Forgot Password?
                  </button>
                </div>

                <button type="submit" disabled={isLoading} className="w-full py-3.5 mt-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-lg transition-all shadow-lg shadow-indigo-600/30 disabled:opacity-70 flex items-center justify-center">
                  {isLoading ? <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : 'Sign In'}
                </button>
              </form>
              
              <p className="text-center mt-6 text-sm text-slate-500 dark:text-slate-400">
                Don't have an account? <button onClick={() => setView('signup')} className="text-indigo-600 dark:text-indigo-400 font-bold hover:underline">Create Account</button>
              </p>
            </motion.div>
          )}

          {view === 'forgot' && (
            <motion.div
              key="forgot"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-md bg-white dark:bg-slate-900 p-8 rounded-3xl shadow-xl border border-slate-200 dark:border-slate-800"
            >
              <button onClick={() => setView('signin')} className="mb-6 flex items-center gap-2 text-sm font-medium text-slate-500 hover:text-slate-900 dark:hover:text-white transition-colors">
                <ArrowLeft className="w-4 h-4" /> Back to Sign In
              </button>
              
              <h2 className="text-2xl font-bold mb-2 text-slate-900 dark:text-white">Reset Password</h2>
              <p className="text-slate-500 dark:text-slate-400 text-sm mb-6">Enter your email or mobile number to receive a reset link/OTP.</p>
              
              <form onSubmit={handleForgot} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1.5 text-slate-700 dark:text-slate-300">Email or Mobile Number</label>
                  <input type="text" value={emailOrMobile} onChange={e => setEmailOrMobile(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white" placeholder="john@example.com" required />
                </div>
                <button type="submit" className="w-full py-3.5 mt-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-lg transition-all shadow-lg shadow-indigo-600/30">
                  Send Reset Link
                </button>
              </form>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
