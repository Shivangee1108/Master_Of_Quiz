import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  User, Mail, Calendar, Trophy, Target, BarChart2, 
  Key, LogOut, Trash2, AlertTriangle, CheckCircle2, Lock, X, Camera, Upload, ArrowLeft, Shield
} from 'lucide-react';
import { useAuthStore } from '../store/useAuthStore';
import { useQuizStore } from '../store/useQuizStore';
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { cn } from '../lib/utils';

export default function Profile() {
  const navigate = useNavigate();
  const { user, logout, updateUser } = useAuthStore();
  const { history, clearHistory } = useQuizStore();

  const [createdAt, setCreatedAt] = useState<string>('');
  
  // Avatar state
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [showAvatarMenu, setShowAvatarMenu] = useState(false);
  const [avatarError, setAvatarError] = useState('');
  
  // Password State
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passError, setPassError] = useState('');
  const [passSuccess, setPassSuccess] = useState('');

  // Delete Account State
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deletePassword, setDeletePassword] = useState('');
  const [deleteError, setDeleteError] = useState('');

  useEffect(() => {
    if (!user) {
      navigate('/');
      return;
    }
    
    if (user.createdAt) {
      setCreatedAt(new Date(user.createdAt).toLocaleDateString(undefined, {
        year: 'numeric', month: 'long', day: 'numeric'
      }));
    } else {
      setCreatedAt('Just now');
    }
  }, [user, navigate]);

  if (!user) return null;

  // Stats calculation
  const totalQuizzes = history.length;
  const averageScore = totalQuizzes > 0 
    ? Math.round(history.reduce((acc, curr) => acc + curr.score, 0) / totalQuizzes) 
    : 0;
  const highestScore = totalQuizzes > 0 
    ? Math.max(...history.map(h => h.score))
    : 0;

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPassError('');
    setPassSuccess('');

    if (!isSupabaseConfigured || !supabase) {
      setPassError('System Error: Database connection is missing.');
      return;
    }

    if (!newPassword || !confirmPassword) {
      setPassError('All fields are required.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setPassError('New passwords do not match.');
      return;
    }

    try {
      const { error } = await supabase.auth.updateUser({ password: newPassword });
      if (error) throw error;

      setPassSuccess('Password updated successfully. Other sessions have been logged out.');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      
      // Clear success message after 3 seconds
      setTimeout(() => setPassSuccess(''), 3000);
    } catch (err: any) {
      setPassError(err.message || 'Failed to update password.');
    }
  };

  const handleDeleteAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    setDeleteError('');

    if (!isSupabaseConfigured || !supabase) {
      setDeleteError('System Error: Database connection is missing.');
      return;
    }

    if (!deletePassword) {
      setDeleteError('Please enter your password to confirm.');
      return;
    }

    try {
      // Re-authenticate to verify password
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: user.emailOrMobile,
        password: deletePassword
      });
      if (signInError) throw new Error('Incorrect password.');
      
      // Delete profile data
      await supabase.from('profiles').delete().eq('id', user.id);
      
      // Note: The user auth record itself should ideally be deleted via a Supabase Edge Function
      // as the client cannot delete its own auth.user directly without admin privileges.
      // But deleting the profile cascades or at least removes their app data.

      clearHistory();
      await logout();
      window.location.href = '/?deleted=true';
    } catch (err: any) {
      setDeleteError(err.message || 'Failed to delete account.');
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const handleAvatarClick = () => {
    if (user.profilePicture) {
      setShowAvatarMenu(!showAvatarMenu);
    } else {
      fileInputRef.current?.click();
    }
  };

  const [isUploading, setIsUploading] = useState(false);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    setAvatarError('');
    const file = e.target.files?.[0];
    if (!file) return;

    if (!isSupabaseConfigured || !supabase) {
      setAvatarError('System Error: Database connection is missing.');
      return;
    }

    // Validate size (5MB)
    if (file.size > 5 * 1024 * 1024) {
      setAvatarError('Image must be less than 5MB');
      return;
    }

    // Validate type
    if (!['image/jpeg', 'image/jpg', 'image/png', 'image/webp'].includes(file.type)) {
      setAvatarError('Only JPG, PNG, and WEBP formats are supported');
      return;
    }

    setIsUploading(true);

    try {
      const fileExt = file.name.split('.').pop();
      const filePath = `${user.id}/${Math.random()}.${fileExt}`;
      
      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(filePath, file, { upsert: true });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('avatars')
        .getPublicUrl(filePath);

      await supabase.from('profiles').update({ profile_picture: publicUrl }).eq('id', user.id);
      updateUser({ profilePicture: publicUrl });
      setShowAvatarMenu(false);
    } catch (err: any) {
      setAvatarError(err.message || 'Failed to upload image.');
    } finally {
      setIsUploading(false);
    }
  };

  const handleRemovePhoto = async () => {
    if (!isSupabaseConfigured || !supabase) return;

    try {
      await supabase.from('profiles').update({ profile_picture: null }).eq('id', user.id);
      updateUser({ profilePicture: undefined });
      setShowAvatarMenu(false);
    } catch (err) {
      console.error('Failed to remove photo', err);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-4xl mx-auto space-y-6"
    >
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-indigo-100 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 rounded-2xl">
            <User className="w-8 h-8" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-slate-900 dark:text-white">My Profile</h1>
            <p className="text-slate-500 dark:text-slate-400">Manage your account settings and view statistics</p>
          </div>
        </div>
        <button 
          onClick={() => navigate('/')}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 font-medium hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors shadow-sm"
        >
          <ArrowLeft className="w-4 h-4" /> Back to Home
        </button>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {/* Left Column: User Info & Stats */}
        <div className="md:col-span-1 space-y-6">
          {/* User Info Card */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-200 dark:border-slate-800">
            <div className="flex flex-col items-center text-center mb-6">
              
              <div className="relative mb-4">
                <button 
                  onClick={handleAvatarClick}
                  className="relative w-28 h-28 rounded-full border-4 border-white dark:border-slate-900 shadow-xl overflow-hidden group focus:outline-none focus:ring-4 focus:ring-indigo-500/30 transition-all"
                >
                  {user.profilePicture ? (
                    <img 
                      src={user.profilePicture} 
                      alt={user.name} 
                      className="w-full h-full object-cover group-hover:brightness-75 transition-all"
                    />
                  ) : (
                    <div className="w-full h-full bg-indigo-100 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 flex items-center justify-center text-4xl font-bold group-hover:bg-indigo-200 dark:group-hover:bg-indigo-500/30 transition-all">
                      {user.name.charAt(0).toUpperCase()}
                    </div>
                  )}
                  
                  {/* Camera overlay on hover/always visible small icon */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40">
                    <Camera className="w-8 h-8 text-white" />
                  </div>
                  {isUploading && (
                    <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                      <div className="w-8 h-8 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    </div>
                  )}
                </button>
                
                {/* Small indicator icon */}
                <div className="absolute bottom-1 right-1 p-2 bg-indigo-600 text-white rounded-full shadow-lg pointer-events-none">
                  <Camera className="w-4 h-4" />
                </div>

                {/* Avatar Menu */}
                <AnimatePresence>
                  {showAvatarMenu && (
                    <>
                      <div className="fixed inset-0 z-40" onClick={() => setShowAvatarMenu(false)} />
                      <motion.div 
                        initial={{ opacity: 0, scale: 0.95, y: 10 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95, y: 10 }}
                        className="absolute top-full mt-2 left-1/2 -translate-x-1/2 z-50 w-48 bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 overflow-hidden"
                      >
                        <button 
                          onClick={() => { fileInputRef.current?.click(); setShowAvatarMenu(false); }}
                          className="w-full px-4 py-3 text-sm font-medium flex items-center gap-2 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                        >
                          <Upload className="w-4 h-4 text-indigo-500" /> Upload New Photo
                        </button>
                        <div className="h-px bg-slate-100 dark:bg-slate-800" />
                        <button 
                          onClick={handleRemovePhoto}
                          className="w-full px-4 py-3 text-sm font-medium flex items-center gap-2 hover:bg-rose-50 dark:hover:bg-rose-500/10 text-rose-600 dark:text-rose-400 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" /> Remove Photo
                        </button>
                      </motion.div>
                    </>
                  )}
                </AnimatePresence>

                {/* Hidden file input */}
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  onChange={handleFileChange} 
                  accept="image/jpeg,image/png,image/webp" 
                  className="hidden" 
                />
              </div>

              {avatarError && (
                <p className="text-xs text-rose-500 font-medium mb-2">{avatarError}</p>
              )}

              <h2 className="text-xl font-bold text-slate-900 dark:text-white capitalize flex items-center justify-center gap-2">
                {user.name}
                {user.role === 'admin' && (
                  <span className="px-2 py-0.5 rounded-md bg-rose-100 text-rose-700 dark:bg-rose-500/20 dark:text-rose-400 text-xs font-bold uppercase tracking-wider flex items-center gap-1">
                    <Shield className="w-3 h-3" /> Admin
                  </span>
                )}
              </h2>
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 flex items-center gap-1 justify-center">
                <Calendar className="w-4 h-4" /> Joined {createdAt}
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1 block">Email / Mobile</label>
                <div className="flex items-center gap-2 px-3 py-2 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-100 dark:border-slate-800">
                  <Mail className="w-4 h-4 text-slate-400" />
                  <span className="text-sm font-medium text-slate-700 dark:text-slate-300 truncate">{user.emailOrMobile}</span>
                  <Lock className="w-3.5 h-3.5 text-slate-400 ml-auto" />
                </div>
                <p className="text-[11px] text-slate-500 mt-1.5 ml-1">
                  Note: Email address cannot be changed after account creation.
                </p>
              </div>
            </div>
          </div>

          {/* Stats Card */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-200 dark:border-slate-800">
            <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
              <BarChart2 className="w-5 h-5 text-indigo-500" /> Statistics
            </h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-100 dark:bg-blue-500/20 text-blue-600 dark:text-blue-400 rounded-lg">
                    <Target className="w-4 h-4" />
                  </div>
                  <span className="text-sm font-medium text-slate-700 dark:text-slate-300">Quizzes Attempted</span>
                </div>
                <span className="font-bold text-slate-900 dark:text-white">{totalQuizzes}</span>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-amber-100 dark:bg-amber-500/20 text-amber-600 dark:text-amber-400 rounded-lg">
                    <BarChart2 className="w-4 h-4" />
                  </div>
                  <span className="text-sm font-medium text-slate-700 dark:text-slate-300">Average Score</span>
                </div>
                <span className="font-bold text-slate-900 dark:text-white">{averageScore}%</span>
              </div>

              <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-emerald-100 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-lg">
                    <Trophy className="w-4 h-4" />
                  </div>
                  <span className="text-sm font-medium text-slate-700 dark:text-slate-300">Highest Score</span>
                </div>
                <span className="font-bold text-slate-900 dark:text-white">{highestScore}%</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Settings & Actions */}
        <div className="md:col-span-2 space-y-6">
          {/* Change Password */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-200 dark:border-slate-800">
            <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
              <Key className="w-5 h-5 text-indigo-500" /> Change Password
            </h3>
            
            {passError && (
              <div className="mb-4 p-3 rounded-xl bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 text-sm font-medium flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" /> {passError}
              </div>
            )}
            
            {passSuccess && (
              <div className="mb-4 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-sm font-medium flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" /> {passSuccess}
              </div>
            )}

            <form onSubmit={handleChangePassword} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1.5 text-slate-700 dark:text-slate-300">Current Password</label>
                <input 
                  type="password" 
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white" 
                  placeholder="••••••••" 
                />
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1.5 text-slate-700 dark:text-slate-300">New Password</label>
                  <input 
                    type="password" 
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white" 
                    placeholder="••••••••" 
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5 text-slate-700 dark:text-slate-300">Confirm New Password</label>
                  <input 
                    type="password" 
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white" 
                    placeholder="••••••••" 
                  />
                </div>
              </div>
              <button 
                type="submit" 
                className="px-6 py-3 mt-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold transition-all shadow-lg shadow-indigo-600/30"
              >
                Update Password
              </button>
            </form>
          </div>

          {/* Danger Zone */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-200 dark:border-slate-800">
            <h3 className="text-xl font-bold mb-6 text-rose-600 dark:text-rose-500">Danger Zone</h3>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <button 
                onClick={handleLogout}
                className="flex-1 py-3 px-4 rounded-xl border-2 border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 text-slate-700 dark:text-slate-300 font-bold flex items-center justify-center gap-2 transition-colors"
              >
                <LogOut className="w-5 h-5" /> Logout
              </button>
              
              <button 
                onClick={() => setShowDeleteModal(true)}
                className="flex-1 py-3 px-4 rounded-xl bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 hover:bg-rose-100 dark:hover:bg-rose-500/20 font-bold flex items-center justify-center gap-2 transition-colors border border-rose-200 dark:border-rose-900/50"
              >
                <Trash2 className="w-5 h-5" /> Delete Account
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Delete Account Modal */}
      <AnimatePresence>
        {showDeleteModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowDeleteModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl overflow-hidden border border-slate-200 dark:border-slate-800"
            >
              <div className="p-6 border-b border-slate-200 dark:border-slate-800 bg-rose-50/50 dark:bg-rose-500/5 flex items-start gap-4">
                <div className="p-3 bg-rose-100 dark:bg-rose-500/20 text-rose-600 dark:text-rose-400 rounded-2xl shrink-0">
                  <AlertTriangle className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-900 dark:text-white">Delete Account?</h3>
                  <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                    This action is permanent and cannot be undone. All your data will be erased.
                  </p>
                </div>
              </div>

              <form onSubmit={handleDeleteAccount} className="p-6 space-y-4">
                {deleteError && (
                  <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 text-sm font-medium flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 shrink-0" /> {deleteError}
                  </div>
                )}
                
                <div>
                  <label className="block text-sm font-medium mb-1.5 text-slate-700 dark:text-slate-300">
                    Verify Password to Continue
                  </label>
                  <input
                    type="password"
                    value={deletePassword}
                    onChange={(e) => setDeletePassword(e.target.value)}
                    placeholder="Enter your password"
                    className="w-full px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent focus:ring-2 focus:ring-rose-500 outline-none dark:text-white"
                  />
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setShowDeleteModal(false);
                      setDeletePassword('');
                      setDeleteError('');
                    }}
                    className="flex-1 py-3 px-4 rounded-xl font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-[2] py-3 px-4 rounded-xl font-bold bg-rose-500 hover:bg-rose-600 text-white transition-colors"
                  >
                    Delete My Account
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
