import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Clock, ChevronRight, ChevronLeft, FastForward, CheckCircle2 } from 'lucide-react';
import { useQuizStore } from '../store/useQuizStore';
import { cn, formatTime } from '../lib/utils';

export default function QuizActive() {
  const navigate = useNavigate();
  const { 
    currentQuiz, 
    answerQuestion, 
    skipQuestion, 
    setCurrentIndex, 
    submitQuiz,
    updateTimeRemaining
  } = useQuizStore();

  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (!currentQuiz) {
      navigate('/');
      return;
    }

    const timer = setInterval(() => {
      if (currentQuiz.timeRemaining <= 0) {
        clearInterval(timer);
        handleSubmit();
      } else {
        updateTimeRemaining(currentQuiz.timeRemaining - 1);
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [currentQuiz?.timeRemaining]);

  if (!currentQuiz) return null;

  const { questions, currentIndex, userAnswers, timeRemaining } = currentQuiz;
  const question = questions[currentIndex];
  const selectedAnswer = userAnswers[question.id];
  const isLastQuestion = currentIndex === questions.length - 1;
  const progress = ((currentIndex + 1) / questions.length) * 100;

  const handleOptionSelect = (option: string) => {
    answerQuestion(question.id, option);
  };

  const handleNext = () => {
    if (!isLastQuestion) setCurrentIndex(currentIndex + 1);
  };

  const handlePrev = () => {
    if (currentIndex > 0) setCurrentIndex(currentIndex - 1);
  };

  const handleSkip = () => {
    skipQuestion(question.id);
    if (!isLastQuestion) setCurrentIndex(currentIndex + 1);
  };

  const handleSubmit = () => {
    setIsSubmitting(true);
    submitQuiz();
    navigate('/results');
  };

  return (
    <div className="max-w-3xl mx-auto py-8">
      {/* Header Info */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-bold capitalize">{currentQuiz.topic} Quiz</h2>
          <p className="text-slate-500 text-sm">{currentQuiz.difficulty} • {currentQuiz.type}</p>
        </div>
        <div className={cn(
          "flex items-center gap-2 px-4 py-2 rounded-full font-mono font-bold text-lg transition-colors",
          timeRemaining < 60 ? "bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400 animate-pulse" : "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300"
        )}>
          <Clock className="w-5 h-5" />
          {formatTime(timeRemaining)}
        </div>
      </div>

      {/* Progress Bar */}
      <div className="mb-8">
        <div className="flex justify-between text-sm font-medium mb-2 text-slate-600 dark:text-slate-400">
          <span>Question {currentIndex + 1} of {questions.length}</span>
          <span>{Math.round(progress)}%</span>
        </div>
        <div className="w-full h-3 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
          <motion.div 
            className="h-full bg-indigo-500 rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.3 }}
          />
        </div>
      </div>

      {/* Question Card */}
      <AnimatePresence mode="wait">
        <motion.div
          key={question.id}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.2 }}
          className="bg-white dark:bg-slate-900 rounded-3xl p-8 shadow-sm border border-slate-200 dark:border-slate-800 mb-8"
        >
          <h3 className="text-2xl font-semibold mb-8 text-slate-900 dark:text-white leading-relaxed">
            {question.text}
          </h3>

          <div className="space-y-4">
            {question.options.map((option, idx) => {
              const isSelected = selectedAnswer === option;
              return (
                <button
                  key={idx}
                  onClick={() => handleOptionSelect(option)}
                  className={cn(
                    "w-full text-left p-5 rounded-xl border-2 transition-all flex items-center justify-between group",
                    isSelected 
                      ? "border-indigo-500 bg-indigo-50 dark:bg-indigo-500/10 text-indigo-700 dark:text-indigo-300" 
                      : "border-slate-200 dark:border-slate-700 hover:border-indigo-300 dark:hover:border-indigo-700 hover:bg-slate-50 dark:hover:bg-slate-800/50"
                  )}
                >
                  <span className="text-lg">{option}</span>
                  <div className={cn(
                    "w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors",
                    isSelected ? "border-indigo-500 bg-indigo-500" : "border-slate-300 dark:border-slate-600 group-hover:border-indigo-300"
                  )}>
                    {isSelected && <CheckCircle2 className="w-4 h-4 text-white" />}
                  </div>
                </button>
              );
            })}
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Navigation Controls */}
      <div className="flex items-center justify-between">
        <button
          onClick={handlePrev}
          disabled={currentIndex === 0}
          className="px-6 py-3 rounded-xl font-medium flex items-center gap-2 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          <ChevronLeft className="w-5 h-5" />
          Previous
        </button>

        <div className="flex gap-4">
          <button
            onClick={handleSkip}
            className="px-6 py-3 rounded-xl font-medium flex items-center gap-2 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            Skip
            <FastForward className="w-5 h-5" />
          </button>
          
          {isLastQuestion ? (
            <button
              onClick={handleSubmit}
              disabled={isSubmitting}
              className="px-8 py-3 rounded-xl font-bold flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white shadow-lg shadow-indigo-600/30 transition-all"
            >
              Submit Quiz
              <CheckCircle2 className="w-5 h-5" />
            </button>
          ) : (
            <button
              onClick={handleNext}
              className="px-8 py-3 rounded-xl font-bold flex items-center gap-2 bg-slate-900 dark:bg-white text-white dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-slate-100 transition-all"
            >
              Next
              <ChevronRight className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
