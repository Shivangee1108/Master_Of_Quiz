import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, History, Trophy, Clock, Target, Play, CheckCircle2 } from 'lucide-react';
import { useQuizStore, Difficulty, QuestionType } from '../store/useQuizStore';
import { useAuthStore } from '../store/useAuthStore';
import { generateQuizQuestions } from '../lib/quizGenerator';
import { cn, formatTime } from '../lib/utils';
import HistoryItem from '../components/HistoryItem';

export default function Dashboard() {
  const navigate = useNavigate();
  const { history, startQuiz, setStatus, deleteHistoryItem, clearHistory } = useQuizStore();
  const { user, logout } = useAuthStore();
  
  const [topic, setTopic] = useState('');
  const [count, setCount] = useState<number | string>(10);
  const [difficulty, setDifficulty] = useState<Difficulty>('Medium');
  const [type, setType] = useState<QuestionType>('Mixed');
  const [isGenerating, setIsGenerating] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const handleDelete = (id: string) => {
    deleteHistoryItem(id);
    setToastMessage("Quiz attempt deleted successfully.");
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleClearHistory = () => {
    if (window.confirm("Are you sure you want to clear all your quiz history? This cannot be undone.")) {
      clearHistory();
      setToastMessage("All history cleared successfully.");
      setTimeout(() => setToastMessage(null), 3000);
    }
  };

  const handleStart = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) return;
    
    setIsGenerating(true);
    setStatus('generating');
    
    try {
      const numCount = Number(count);
      const questions = await generateQuizQuestions(topic, numCount, difficulty, type);
      const timeLimit = numCount * 30; // 30 seconds per question
      startQuiz(topic, difficulty, type, questions, timeLimit);
      navigate('/quiz');
    } catch (error) {
      console.error(error);
      setStatus('idle');
    } finally {
      setIsGenerating(false);
    }
  };

  const totalQuizzes = history.length;
  const averageScore = totalQuizzes > 0 
    ? Math.round(history.reduce((acc, curr) => acc + curr.score, 0) / totalQuizzes) 
    : 0;

  const numCount = Number(count);
  const isValidCount = count !== '' && !isNaN(numCount) && numCount >= 5 && numCount <= 100;

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <section className="text-center py-12 px-4 rounded-3xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 text-white shadow-xl relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-20"></div>
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative z-10"
        >
          <h1 className="text-4xl md:text-6xl font-extrabold mb-4 tracking-tight">Master of Quiz</h1>
          <p className="text-lg md:text-xl text-indigo-100 max-w-2xl mx-auto mb-8">
            Generate infinite quizzes on any topic instantly. Challenge yourself and track your progress.
          </p>
        </motion.div>
      </section>

      <div className="grid md:grid-cols-12 gap-8">
        {/* Setup Form */}
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="md:col-span-7 bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-200 dark:border-slate-800"
        >
          <div className="flex items-center gap-2 mb-6">
            <Sparkles className="w-6 h-6 text-indigo-500" />
            <h2 className="text-2xl font-bold">Generate New Quiz</h2>
          </div>
          
          <form onSubmit={handleStart} className="space-y-6">
            <div>
              <label className="block text-sm font-medium mb-2 text-slate-700 dark:text-slate-300">
                What do you want to learn about?
              </label>
              <input 
                type="text" 
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="e.g., Python, World War II, React, Geography..."
                className="w-full px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all dark:text-white"
                required
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2 text-slate-700 dark:text-slate-300">
                  Number of Questions
                </label>
                <input 
                  type="number"
                  value={count}
                  onChange={(e) => setCount(e.target.value)}
                  className={cn(
                    "w-full px-4 py-3 rounded-xl border bg-transparent focus:ring-2 outline-none dark:text-white transition-all [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none",
                    count !== '' && (Number(count) < 5 || Number(count) > 100)
                      ? "border-rose-500 focus:ring-rose-500 focus:border-rose-500"
                      : "border-slate-300 dark:border-slate-700 focus:ring-indigo-500 focus:border-indigo-500"
                  )}
                />
                <div className="mt-2 space-y-1">
                  {count !== '' && Number(count) < 5 && (
                    <p className="text-sm text-rose-500 font-medium">Please enter at least 5 questions.</p>
                  )}
                  {count !== '' && Number(count) > 100 && (
                    <p className="text-sm text-rose-500 font-medium">Maximum 100 questions are allowed.</p>
                  )}
                  <div className="text-xs text-slate-500 dark:text-slate-400 mt-2">
                    📝 Note: Numbers Range 5-100
                  </div>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2 text-slate-700 dark:text-slate-300">
                  Difficulty
                </label>
                <select 
                  value={difficulty}
                  onChange={(e) => setDifficulty(e.target.value as Difficulty)}
                  className="w-full px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white"
                >
                  <option value="Easy">Easy</option>
                  <option value="Medium">Medium</option>
                  <option value="Hard">Hard</option>
                </select>
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-2 text-slate-700 dark:text-slate-300">
                Question Type
              </label>
              <div className="flex gap-2">
                {['Mixed', 'Multiple Choice', 'True/False'].map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setType(t as QuestionType)}
                    className={cn(
                      "flex-1 py-2 px-3 rounded-lg border text-sm font-medium transition-all",
                      type === t 
                        ? "border-indigo-500 bg-indigo-50 text-indigo-700 dark:bg-indigo-500/20 dark:text-indigo-300"
                        : "border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800"
                    )}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            <button
              type="submit"
              disabled={isGenerating || !topic.trim() || !isValidCount}
              className="w-full py-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-lg flex items-center justify-center gap-2 transition-all disabled:opacity-70 disabled:cursor-not-allowed shadow-lg shadow-indigo-600/30"
            >
              {isGenerating ? (
                <>
                  <div className="w-6 h-6 border-4 border-white/30 border-t-white rounded-full animate-spin"></div>
                  Generating Magic...
                </>
              ) : (
                <>
                  <Play className="w-5 h-5 fill-current" />
                  Start Quiz Now
                </>
              )}
            </button>
          </form>
        </motion.div>

        {/* Stats & History */}
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="md:col-span-5 space-y-6"
        >
          {/* Mini Stats */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200 dark:border-slate-800 flex items-center gap-4">
              <div className="p-3 bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-xl">
                <Trophy className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">Avg Score</p>
                <p className="text-2xl font-bold">{averageScore}%</p>
              </div>
            </div>
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-200 dark:border-slate-800 flex items-center gap-4">
              <div className="p-3 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-xl">
                <Target className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">Quizzes</p>
                <p className="text-2xl font-bold">{totalQuizzes}</p>
              </div>
            </div>
          </div>

          {/* Recent History */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-200 dark:border-slate-800 h-[340px] flex flex-col">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <History className="w-5 h-5 text-slate-500" />
                <h3 className="text-lg font-bold">Recent Quizzes</h3>
              </div>
              {history.length > 0 && (
                <button onClick={handleClearHistory} className="text-xs font-medium text-rose-500 hover:text-rose-600 hover:underline transition-colors">
                  Clear All
                </button>
              )}
            </div>
            
            <div className="flex-1 overflow-y-auto pr-2 space-y-3 custom-scrollbar relative">
              {history.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-slate-400 space-y-2">
                  <History className="w-12 h-12 opacity-20" />
                  <p>No quizzes taken yet.</p>
                </div>
              ) : (
                <AnimatePresence mode="popLayout">
                  {history.slice(0, 10).map((item) => (
                    <HistoryItem key={item.id} item={item} onDelete={handleDelete} />
                  ))}
                </AnimatePresence>
              )}
            </div>
          </div>
        </motion.div>
      </div>

      {/* Toast Notification */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-slate-900 dark:bg-white text-white dark:text-slate-900 px-6 py-3 rounded-full shadow-xl font-medium text-sm flex items-center gap-2"
          >
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
            {toastMessage}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
