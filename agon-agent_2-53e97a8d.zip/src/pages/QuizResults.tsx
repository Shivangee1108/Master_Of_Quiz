import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import confetti from 'canvas-confetti';
import { Trophy, Clock, CheckCircle2, XCircle, RotateCcw, Home, Download, AlertCircle } from 'lucide-react';
import { useQuizStore } from '../store/useQuizStore';
import { cn, formatTime } from '../lib/utils';

export default function QuizResults() {
  const navigate = useNavigate();
  const { history, resetCurrentQuiz } = useQuizStore();
  
  const result = history[0];

  useEffect(() => {
    if (!result) {
      navigate('/');
      return;
    }

    if (result.score >= 70) {
      const duration = 3 * 1000;
      const end = Date.now() + duration;

      const frame = () => {
        confetti({
          particleCount: 5,
          angle: 60,
          spread: 55,
          origin: { x: 0 },
          colors: ['#6366f1', '#a855f7', '#ec4899']
        });
        confetti({
          particleCount: 5,
          angle: 120,
          spread: 55,
          origin: { x: 1 },
          colors: ['#6366f1', '#a855f7', '#ec4899']
        });

        if (Date.now() < end) {
          requestAnimationFrame(frame);
        }
      };
      frame();
    }
  }, [result, navigate]);

  if (!result) return null;

  const handleHome = () => {
    resetCurrentQuiz();
    navigate('/');
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-emerald-500';
    if (score >= 50) return 'text-amber-500';
    return 'text-rose-500';
  };

  const getScoreMessage = (score: number) => {
    if (score >= 90) return 'Outstanding! You are a master.';
    if (score >= 70) return 'Great job! Solid knowledge.';
    if (score >= 50) return 'Good effort! Room for improvement.';
    return 'Keep learning! Try again.';
  };

  return (
    <div className="max-w-4xl mx-auto py-8 space-y-8">
      {/* Overview Cards */}
      <div className="grid md:grid-cols-3 gap-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:col-span-3 bg-white dark:bg-slate-900 rounded-3xl p-8 shadow-sm border border-slate-200 dark:border-slate-800 text-center relative overflow-hidden"
        >
          <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500"></div>
          <h2 className="text-2xl font-bold mb-2">Quiz Completed!</h2>
          <p className="text-slate-500 mb-6 capitalize">Topic: {result.topic} • {result.difficulty}</p>
          
          <div className="flex flex-col items-center justify-center">
            <div className="relative mb-4">
              <svg className="w-48 h-48 transform -rotate-90">
                <circle
                  cx="96"
                  cy="96"
                  r="88"
                  className="stroke-slate-100 dark:stroke-slate-800"
                  strokeWidth="12"
                  fill="none"
                />
                <circle
                  cx="96"
                  cy="96"
                  r="88"
                  className={cn("transition-all duration-1000 ease-out", 
                    result.score >= 80 ? "stroke-emerald-500" :
                    result.score >= 50 ? "stroke-amber-500" : "stroke-rose-500"
                  )}
                  strokeWidth="12"
                  fill="none"
                  strokeDasharray={2 * Math.PI * 88}
                  strokeDashoffset={2 * Math.PI * 88 * (1 - result.score / 100)}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className={cn("text-5xl font-extrabold", getScoreColor(result.score))}>
                  {result.score}%
                </span>
              </div>
            </div>
            <p className="text-xl font-medium text-slate-700 dark:text-slate-300">
              {getScoreMessage(result.score)}
            </p>
          </div>
        </motion.div>

        {/* Stats */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-200 dark:border-slate-800 flex items-center gap-4"
        >
          <div className="p-4 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-xl">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <div>
            <p className="text-sm text-slate-500 font-medium">Correct</p>
            <p className="text-2xl font-bold">{result.correctAnswers} / {result.totalQuestions}</p>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-200 dark:border-slate-800 flex items-center gap-4"
        >
          <div className="p-4 bg-rose-100 dark:bg-rose-900/30 text-rose-600 dark:text-rose-400 rounded-xl">
            <XCircle className="w-8 h-8" />
          </div>
          <div>
            <p className="text-sm text-slate-500 font-medium">Wrong / Skipped</p>
            <p className="text-2xl font-bold">{result.wrongAnswers + result.skipped}</p>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-200 dark:border-slate-800 flex items-center gap-4"
        >
          <div className="p-4 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-xl">
            <Clock className="w-8 h-8" />
          </div>
          <div>
            <p className="text-sm text-slate-500 font-medium">Time Taken</p>
            <p className="text-2xl font-bold">{formatTime(result.timeTaken)}</p>
          </div>
        </motion.div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-wrap justify-center gap-4">
        <button 
          onClick={handleHome}
          className="px-6 py-3 rounded-xl font-medium flex items-center gap-2 bg-slate-900 dark:bg-white text-white dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-slate-100 transition-colors"
        >
          <Home className="w-5 h-5" />
          Back to Dashboard
        </button>
        <button 
          onClick={() => window.print()}
          className="px-6 py-3 rounded-xl font-medium flex items-center gap-2 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
        >
          <Download className="w-5 h-5" />
          Save as PDF
        </button>
      </div>

      {/* Detailed Review */}
      <div className="mt-12">
        <h3 className="text-2xl font-bold mb-6 flex items-center gap-2">
          <AlertCircle className="w-6 h-6 text-indigo-500" />
          Detailed Review
        </h3>
        
        <div className="space-y-6">
          {result.questions.map((q, idx) => {
            const userAnswer = result.userAnswers[q.id];
            const isCorrect = userAnswer === q.correctAnswer;
            const isSkipped = !userAnswer;

            return (
              <div key={q.id} className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-200 dark:border-slate-800">
                <div className="flex items-start gap-4 mb-4">
                  <div className={cn(
                    "flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm text-white mt-1",
                    isCorrect ? "bg-emerald-500" : isSkipped ? "bg-slate-400" : "bg-rose-500"
                  )}>
                    {idx + 1}
                  </div>
                  <div>
                    <h4 className="text-lg font-medium text-slate-900 dark:text-white">{q.text}</h4>
                    <div className="mt-4 space-y-2">
                      {q.options.map((opt, oIdx) => {
                        const isSelected = userAnswer === opt;
                        const isActualCorrect = q.correctAnswer === opt;
                        
                        let optClass = "border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50";
                        if (isActualCorrect) {
                          optClass = "border-emerald-500 bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-300";
                        } else if (isSelected && !isActualCorrect) {
                          optClass = "border-rose-500 bg-rose-50 dark:bg-rose-500/10 text-rose-700 dark:text-rose-300";
                        }

                        return (
                          <div key={oIdx} className={cn("p-3 rounded-lg border flex items-center justify-between", optClass)}>
                            <span>{opt}</span>
                            {isActualCorrect && <CheckCircle2 className="w-5 h-5 text-emerald-500" />}
                            {isSelected && !isActualCorrect && <XCircle className="w-5 h-5 text-rose-500" />}
                          </div>
                        );
                      })}
                    </div>
                    
                    <div className="mt-4 p-4 rounded-xl bg-indigo-50 dark:bg-indigo-500/10 border border-indigo-100 dark:border-indigo-500/20">
                      <p className="text-sm text-indigo-900 dark:text-indigo-200">
                        <strong className="font-semibold block mb-1">Explanation:</strong>
                        {q.explanation}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
